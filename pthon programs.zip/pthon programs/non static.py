class Malik:
    def mub(self):
        self.a=1000
        self.b=3000
        self.c=0
    def add(self):
        self.c=self.a+self.b
        print(self.c)
t1=Malik()
t1.mub()
t1.add()
            
