n=int(input("enter a number:"))
for i in range(n,-1,-1):
    n=n-1
    for j in range(i,-1,-1):
        print("*",j)
        break
print( )

