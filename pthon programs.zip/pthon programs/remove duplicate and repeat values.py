''' removing duplicate elements and repeat elements in list variable'''
x=[1,2,3,4,5,1,2,4]
s=[]
l=[]
for i in x:
    if i not in s:
        s.append(i)
    else:
        l.append(i)
print(s)
print(l)
