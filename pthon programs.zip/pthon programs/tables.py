'''a=int(input("enter any number"))
while a<=10:
    b=1
    while b<=9:
        b=b+1
        print(a,"*",b,"=",a*b)
    print("\n")
    break
  
a = 2
try:
    i=int(a)
    while i <= 10:
        b = 1
        while b <= 9:
            b = b + 1
            print(i, "*", b, "=", i * b)
        print("\n")
        break
except(ValueError):
    print("invllkjioj")
    '''
a=int(input("enter any one number"))
for j in range(10):
    j=j+1
    print(a,"*",j,"=",a*j)
    












