'''import sys
print(sys.argv)
print(len(sys.argv))
for p in sys.argv:
    print(p)
'''

##### cmd lines arrugement with excaption handling

import sys
print(sys.argv)
try:
    x=sys.argv[1]
    i=int(x)
    y=sys.argv[2]
    j=int(y)
    print(i+j)
except(ValueError):
    print("enter numerical arguments")
except(IndexError):
    print("enter two arguments")
