##Method over loading
'''class Test:
    def m1(self):
        print("in no parameter m1 of test class")
    def m1(self,a):
        print("in one parameter m1 of test class")
    def m1(self,a,b):
        print("in two parameter m1 of test class")
t1=Test()
t1.m1(100,44)


class Test:
    def add(self,a,*args):
        if a=='int':
            result=0
        if a=='str':
            result=' '
        for i in args:
            result=result+i
            print(result)
x1=Test()
x1.add('int',10+20+33)
x1.add('str','lokesh'+'python'+'good')


class X:
    def m1(self):
        print("in m1 of X class")
    def m2(self):
        print("in m2 of X class")
        
class Y(X):
    def m2(self):
        print("in m2 of y class")
    def m3(self):
        print("in m3 of y class")
y1=Y()
y1.m1()
y1.m2()
y1.m3()
x1=X()
x1.m1()
x1.m2()

class sbi:
    def __init__(self):
        print("State Bank Of India")
    def acnt2(self):
        print("in this bank minmum zero balance account")
class hdfc(sbi):
    def __init__(self):
        print("HDFC BANK IN HYD")
    def acnt2(self):
        print("in this bank minmum bal is 500")
class icic(hdfc,sbi):
    def __init__(self):
        print("indian coorparation indian coorpation")
    def acnt(self):
        print("in this bank minmum bal is 1000")
x1=icic()
x1.acnt2()
x1.acnt()
############
class X:
    def m1(self):
        print("in m1 of X class")
    def m2(self):
        print("in m2 of X class")
    def __str__(self):
        return "mubarak"
x1=X()
print(x1)
p=x1.__str__()
x1.m1()
x1.m2()
x2=X()
print(x2)
q=x2.__str__()
x2.m1()
x2.m2()
###############
'''
class Test:
    def __init__(self,msg):
        self.msg=msg
    def __str__(self):
        return self.msg
t1=Test('mubar')
print(t1)
t2=Test('malik')
print(t2)
t3=Test("salman")
print(t3)
'''
#########
class X:
    def m1(self):
        print("in m1 of class X")
    def m2(self):
        print("in m2 of class X")
class Y(X):
    def m2(self):
        print("in m2 of class Y")
    def m3(self):
        print("in m3 of class Y")
    def display(self):
        self.m1()
        self.m2()
        self.m3()
        super().m2()
       
y1=Y()
y1.display()

###########

class X:
    def __init__(self):
        print(" in construtor of class X")
class Y(X):
    def __init__(self):
        print("in constructor of class Y")
class Z(Y,X):
    def __init__(self):
        print("in constructor of class Z")
    
y1=Z()

##############
    
class X:
    def __init__(self):
        self.a=100
        self.b=200
class Y(X):
    def __init__(self):
        super().__init__()
        self.c=300
        self.d=400

y1=Y()
print(y1.c)
print(y1.d)
print(y1.a)
print(y1.b)


#########
class X:
    def __init__(self,a,b):
        self.a=a
        self.b=b
class Y(X):
    def __init__(self,c,d):
        super().__init__(89885,5255)
        self.c=c
        self.d=d
y1=Y(55,588)
print(y1.c)
print(y1.d)
print(y1.a)
print(y1.b)

######
class X:
    def __init__(self,a,b):
        self.a=a
        self.b=b
class Y(X):
    def __init__(self,a,b,c,d):
        super().__init__(a,b)
        self.c=c
        self.d=d
y1=Y(55,588,5555,222)
print(y1.c)
print(y1.d)
print(y1.a)
print(y1.b)'''





















































        








