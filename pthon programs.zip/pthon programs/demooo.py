class Muba:
    a=100
    b=200
    def display(self):
        print(Muba.a)
        print(Muba.b)
    def modify(self):
      Muba.a=Muba.a+50
      Muba.b=Muba.b-100
m=Muba()
m.modify()
m.display()


