import sys
print(__name__)
if __name__=="__main__":
    try:
        x=sys.argv[1]
        i=int(x)
        y=sys.argv[2]
        j=int(y)
        print(i+j)
    except(ValueError):
        print("enter numerical arguments")
    except(IndexError):
        print("enter two arguments")
#### other file with name of "mainmodule2.py"
