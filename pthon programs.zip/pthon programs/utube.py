class A:
    def m1(self):
        print("m1 from class A")
class B(A):
    def m2(self):
        print("m2 from class B")
        super().m1()
class C(A):
    def m3(self):
        print("m3 from class C")
        super().m1()
class D(B,C):
    def m4(self):
        print("m4 from class D")
        super().m4()

v1=D()
v1.m4()

