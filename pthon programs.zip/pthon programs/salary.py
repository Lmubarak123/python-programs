x=int(input("enter salary"))
if x>=30000:
    print("name:pavan")
    print("add:kadapa")
    print("P\F:200")
    print("salary:100000")
elif x<30000:
    print("name:malik")
    print("add:tiupathi")
    print("P\F:200")
    print("salary:25000")
elif x<20000:
    print("name:pavan")
    print("add:kadapa")
    print("P\F:200")
    print("salary:15000")
else:
    print("there no employee")
    
