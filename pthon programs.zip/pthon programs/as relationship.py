class X:
    a=100
    def __init__(self):
        self.b=200
    def muba(self):
        print("hellol muba")

class Y:
    c=300
    def __init__(self):
        self.d=400
    def hai(self):
        print("hello hai")
    def display(self):
        print(Y.c)
        print(self.d)
        self.hai()
        print(X.a)
        x1=X()
        print(x1.b)
        x1.muba()
y=Y()
y.display()
