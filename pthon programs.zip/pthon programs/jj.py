class Savingac:
    acbal=0
    x=0.0
    intrest=0.0
    def __init__(self,x,intrest,acbal):
        self.x=x
        self.intrest=intrest
        self.acbal=acbal
        self.x=self.acbal*self.intrest
        print(self.x)
x1=Savingac(10,0.05,500)


    
