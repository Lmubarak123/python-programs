a=int(input("enter one number"))
for i in range(10):
        i=i+1
        print(a,"X",i,"=",a*i)

