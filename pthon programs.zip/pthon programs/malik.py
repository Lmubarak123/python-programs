class x:
    def __init__(self):
        self.a=10
x1=x()
print(x1.a)
