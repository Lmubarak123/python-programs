x=input('enter x value')
y=input('enter y valure')
    print(x+b)
