x=[['park','dailymalik','munch'],['maza','thumup'],['cheppal','shoes']]
i='chock'
j='drinks'
k='foot'
z=input("enter chock,driks,foot")
if i==z:
    print(x[0])
elif j==z:
    print(x[1])
elif k==z:
    print(x[2])
    
