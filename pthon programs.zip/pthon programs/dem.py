from sys import argv
print(argv[1])
