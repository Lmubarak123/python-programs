class Account:
    acbal=0.0   
    def __init__(self,acbal):
        self.acbal=acbal
        if acbal>=0:
            print(acbal)
        else:
            acbal=0.0
            print("initial balance was invalid error")
    def crd(self,crdamt):
        self.acbal=self.acbal+crdamt
    def debt(self,debtamt):
        if debtamt>=self.acbal:
            print("Debit amount is greaterthan current balance")
        else:
            self.acbal=self.acbal-debtamt
    def get(self):
        print(self.acbal)
y1=Account(10)
y1.crd(500)
y1.debt(100)
y1.get()

class Savingac(Account):
    x=0.0
    intrest=0.0
    def __init__(self,x,intrest,acbal):
        super().__init__(500)
        self.x=x
        self.intrest=intrest
        self.acbal=acbal
        self.x=self.acbal*self.intrest
        print(self.x)
        print(self.acbal)
        
y1=Savingac(100,0.05,Account.acbal)

















'''y1=Account(10)
y1.crd(500)
y1.debt(100)
y1.get()
z1=Savingac()
z1.get()

   class Savingac:
    def __init__(self):
        
class Checkingac(Account):
    def __init__(self):
        self.c1=c1
class Currentac(Account,Checkingac):
    def __init__(self):

          super(10)
        super().crd(500)
        super().debt(100)
        super().get()
'''
