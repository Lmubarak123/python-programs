'''function example'''
x=" mubarak is a bad boy for someonces"
print(x)
words=x.split()
for i in words:
    print(i.upper())
print()
for i in words:
    print(i.title())
print()
for i in words:
    print(len(i))
print()
