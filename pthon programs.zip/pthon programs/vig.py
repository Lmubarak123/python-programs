x=int(input("enter first number"))
y=int(input("enter second number"))
c=x+y
print(c)
if c==50:
    print("the number is equal")
elif c>=50:
    d=c*2
    print(d)
else:
    d=c/2
    print(d)






