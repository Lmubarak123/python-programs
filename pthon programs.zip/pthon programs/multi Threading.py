'''
import threading
class x(threading.Thread):
    def run (self):
        for p in range(1,101):
            print(p)
class y(threading.Thread):
    def run (self):
        for q in range(101,201):
            print(q)
x1=x()
x1.start()
y1=y()
y1.start()

###### ex :-

import threading
class x(threading.Thread):
    def run (self):
        mync()
class y(threading.Thread):
    def run(self):
        mync()
def mync():
    for q in range(0,101):
            print(q)
x1=x()
x1.start()
y1=y()
y1.start()
'''
#####
import threading
class x(threading.Thread):
    def run (self):
        for p in range(1,101):
            print(p)
x1=x()
x1.start()
x2=x()
x2.start()














            













    
