class Test:
    def __init__(self):
        print("hai this mubarak")
    def display(self):
        print("print this given init funtion")
t1=Test()
t1.display()
t2=Test()
t2.display()
t3=Test()
t3.display()
''' this constructor  is used to define and insillize non-static varaible of class at a time of
creating "obejct" '''

'''  other example is given below'''
'''
class Test:
    def__init__(self):
        self.a=100
        self.b=200
    def display(self):
        print(self.a)
        print(self.b)
x1=Test()
x1.display()
x2=Test()
x2.display()
x3=Test()
x3.display()
'''
