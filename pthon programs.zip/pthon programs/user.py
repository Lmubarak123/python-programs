while True:
    x=input("enter asname:")
    y=input("enter a pwd:")
    if x!=mubarak and y!=muba:
        print("hai mubarak")
    else:
         print("your x or y invalid")
        
