#### web scrapping
'''import requests
url='https://api.speedcurve.com/v1/urls?days=1'
key='cn685aw5tj0i475zdzosbmtpslry82'
password='Any_password'
response=requests.get(url,auth=(key,password))
d=(response.json())
print(d)
for a,b in d.items():
    for c in b:
        print("site_id:",c.get('site_id'))
        print("----------------")
        urls=c.get("urls")
        for d in urls:
            print(d.get('url_id'))'''

### example 2
import csv
import urllib.request
urllib.request.urlopen("http://api.kibot.com/?action=login&user=guest&password=guest")
response=urllib.request.urlopen("http://api.kibot.com/?action=history&symbol=MSFT&interval=daily&period=10")
html=response.read()
print(html)
dat=html.decode("utf-8")
print(dat)
recs=dat.split()
print(recs)
outrecs=[]
for rec in recs:
    out1=rec.split(",")
    outrecs.append(out1)
print(outrecs)
x=open("mycus123.csv","w")
writer=csv.writer(x)
writer.writerows(outrecs)
x.close()

























