
import cx_Oracle
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
print("connection is established")
con.close()
print(" connection is closed")

'''import cx_Oracle
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
cur=con.cursor()
cur.execute("select * from mubatable")
for res in cur:
    print(res)
cur.close()
con.close()

import cx_Oracle
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
cur=con.cursor()
cur.execute("select * from product order by pcost desc")
for result in cur:
    print(result)
cur.close()
con.close()

### hight cost products display

import cx_Oracle
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
cur=con.cursor()
cur.execute("select * from product order by pcost desc")
result=cur.fetchmany()
for p in result:
    print(p)
cur.close()
con.close()

### establistion of exception Handling technique inside the our data basse program

import cx_Oracle
con=None
cur=None
try:
    con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
    print("connection is established")
    cur=con.cursor()
    cur.execute("select * from product order by pcost desc")
    result=cur.fetchmany()
    for p in result:
        print(p)
except:
    print("error is occured")
finally:
    if cur !=None:
        cur.close()
        
        if con !=None:
            con.close()
    
        print("connection is closed")
    

#### Excuting DML commands

import cx_Oracle
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
cur=con.cursor()
cur.execute("delete from product where sno=1003")
print("the no of delect records are",cur.rowcount)
cur.close()
con.close()

### Transaction Management ... create customer table in oracle data base
import cx_Oracle
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
cur=con.cursor()
cur.execute("update product set pcost=pcost+100 where sno=1001")
if cur.rowcount==1:
    cur.execute("update product set pcost=pcost-100 where sno=1002")
    if cur.rowcount==1:
        con.commit()
        print("Transction is successfully")
    else:
        con.rollback()
        print("Transcation is failed")
else:
    print("account is exit")
cur.close()
con.close()

import cx_Oracle
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
cur=con.cursor()
cur.execute("select * from product where sno=1001")
for p in cur:
    print(p)
cur.execute("select * from product where sno=1004")
for q in cur:
    print(q)
cur.close()
con.close()


#### prepare method
import cx_Oracle
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
cur=con.cursor()
cur.prepare("select * from product where sno=:mm")
cur.execute(None,{'mm':1001})
for p in cur:
    print(p)
cur.execute(None,{'mm':1005})
for q in cur:
    print(q)
cur.close()
con.close()

#### Inserting table through python ( inserting multiple records into the Data Base table:

import cx_Oracle
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
rows=[(1,"aur"),(2,"mubarak"),(3,"malik"),(4,"rafi"),(5,"masthanvali"),(6,"mastan")]
cur=con.cursor()
cur.executemany("""insert into mytab(id,data) values (:1,:2)""",rows)
con.commit()
cur.close()
cur2=con.cursor()
cur2.execute('select * from mytab')
for p in cur2:
    print(p)
cur2.close()
con.close()
'''























                      





    



















































    

























