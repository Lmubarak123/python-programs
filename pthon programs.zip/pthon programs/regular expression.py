'''import re
rex=r"[a-zA-Z]+ \d+"
matches=re.findall(rex,""" June 24, August 9, Dec 12,12 Feb""")
for match in matches:
    print("Full match:",match)

#######################
import re
rex=r"([a-zA-Z]+) \d+"
mubarak=re.findall(rex,""" June 13,August 01,Dec 29,June""")
for muba in mubarak:
    print(muba)

import re
rex=r"[a-zA-Z]+ \d+"
mubarak=re.finditer(rex,"""June 22, Augest 23,Dec 29,Jun""")
for muba in mubarak:
    print(" muba at index",muba.start(),muba.end())

###############
import re
rex=re.compile(r"(\w+) World")
result=rex.search(""" heloo muba 7 World  is the largest World 777""")
if result:
    print(result.start(),result.end())
#############

import re
reg=re.compile (r"\d{10}")
while True:
    mobile=input("Enter your mobile number")
    if len (mobile)==10:
        result=reg.search(mobile)
        if result:
            print(" your mobile number is Valid")
            break
        else:
            print("mobile number should be in digits only")
    else:
        print("moblie number should contain 10 digits")
print("\n\n")
print("*"*60)
print("Thankyou  now you allow to call's")
print("*"*60)

################
import re
reg=re.compile(r"(\W+) World")
result=reg.findall("Hello World,Mubarak World, Python World, Deloper World , In World, Tcscompany World")
for res in result:
    print(res)
##################
import re
reg=re.compile(r"[a-zA=Z]+")
fb=open("muba.txt")
data=fb.read()
res=reg.findall(data)
for result in res:
    print(result)

###################
import re
reg=re.compile(r"\d{3}.\d{1}.\d{2}.\d{2}")
fd=open("ip.txt")
data=fd.read()
res=reg.findall(data)
for result in res:
    print(result)'''
######################
import re
reg=re.compile(r"[a-zA-Z0-9]+@[a-z]+.[a-z]+")
fd=open("gmail.txt")
data=fd.read()
res=reg.findall(data)
for result in res:
    print(result)


 





















