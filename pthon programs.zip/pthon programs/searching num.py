x=[1112,22550,525630,4550,5000,6666]
print(x)
s=0
print('''Hello
     SBI customer''')
while True:
    i=int(input("enter pin "))
    if i in x:
        print("entered pin is successful ")
        break
    else:
        s=s+1
        if s==3:
            print('''"\n"SORRY 
        ur searching number is expaire for tody
         Try after 24hours
         Thankyou''')
            break
    print('''ENTERED PIN IS WRONG
          TRY AGAIN''')
