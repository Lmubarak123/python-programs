x={"choculate":["parak","dailry malik","munch"],"cooldrinks":["spirt","cock","thumsup"],
   "clothes":["shirt","paint","Tshirt"]}
print(x)
for a,b in x.items():
    print("------------------------------------------")
    print(a)
    print("........................................................")
    for i in b:
        print(i)
