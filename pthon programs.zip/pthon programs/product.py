class Product:
    """ BIG BAZER PRODUCTS"""
    shopname='MM'
    def __init__(self,choculates,cooldrinks,clothes,footwares,housewares):
        self.choculates=choculates
        self.cooldrinks=cooldrinks
        self.clothes=clothes
        self.footwares=footwares
        self.housewares=housewares
    def chock(self):
        c=['fivestar','park','asha','munch','slik']
        print(c)
    def cool(self):
        d=['thumup','sprit','cocola','mazza']
        print(d)
    def cloth(self):
        i=['shirt','Tshirt','paint','shorts']
        print(i)
    def foot(self):
        p=['shoos','chapaals']
        print(p)
    def houses(self):
        h=['waterbottle','washingmeachin','cooler']
        print(h)
    def dispaly(self):
        print(self.choculates)
        print(self.cooldrinks)
        print(self.clothes)
        print(self.footwares)
        print(self.housewares)
h1=Product('park','mazza','shirt','chappal','watebottel')
h1.chock()
h1.cool()
h1.cloth()
h1.foot()
h1.houses()

        
