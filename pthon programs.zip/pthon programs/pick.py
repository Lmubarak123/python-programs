import pickle
with open("hello","rb") as x:
    data=pickle.load(x)
    for p in data:
        print(p)









'''data=[["hjh",595,55],["hhii",5545,65,665],["klhjjii",544,55]]
x=open("hello","wb")
pickle.dump(data,x)
x.close()'''
