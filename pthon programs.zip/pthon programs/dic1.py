x={"java":80,"python":99,"aws":78,"devops":69}
print(x)
print(x.get("aws"))
print(["python"])
x["aws"]=85
print(x)
x["hadoop"]=82
print(x)
print("devops" in x)
print(99 in x)
for p in x:
    print(p,x[p])
