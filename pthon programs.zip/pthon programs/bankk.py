class Cust:
    cbname="SBI"
    def __init__(self,cname,cadd,cacno,cbal):
        self.cname=cname
        self.cadd=cadd
        self.cacno=cacno
        self.cbal=cbal
    def __str__(self):
        return self.cname+" "+self.cadd+" "+str(self.cacno)+" "+str(self.cbal)+" "+Cust.cbname
    def deposite(self,admt):
        self.cbal=self.cbal+admt
    def withdraw(self,awt):
        self.cbal=self.cbal-awt
    def display(self):
        print(self.cname)
        print(self.cadd)
        print(self.cacno)
        print(self.cbal)
c1=Cust("mubarak","kadapa",10001,1000000.00)
c2=Cust("pavan","kadapa",10002,520000.00)
c3=Cust("vinay","adoni",10003,696533.00)
c4=Cust("rafi","nellor",10004,900000.00)
c1.deposite(500)
c1.withdraw(1000)
c2.deposite(500)
c2.withdraw(1000)
c3.deposite(500)
c3.withdraw(500)
c4.deposite(500)
c4.withdraw(506)

x=[c1,c2,c3,c4]
for i in x:
    print(i)
print("...............after sorting...........................................")
x.sort(key= lambda c:c.cacno,reverse=True)
for p in x:
    print(p)




