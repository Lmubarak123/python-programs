import mainmodule
print(__name__)
print("begin")
print("end")
