class Emp:
    """employee app"""
    empcnt=0
    def __init__(self,ename,eadd,eid,esal):
        self.ename=ename
        self.eadd=eadd
        self.eid=eid
        self.esal=esal
        Emp.empcnt=Emp.empcnt+1
    def __del__(self):
        Emp.empcnt=Emp.empcnt-1
    def deposite(self,damt):
        self.esal=self.esal+damt
    def withdraw(self,wamt):
        self.esal=self.esal-wamt
    def display(self):
        print(self.ename)
        print(self.eadd)
        print(self.eid)
        print(self.esal)
        
t1=Emp("mubarak","kadapa",10001,35000.00)
t1.deposite(100.00)
t1.withdraw(200.00)
t1.display()
print("....................................")
t2=Emp("malik","tirupathi",10002,39000.00)
t2.deposite(100.00)
t2.withdraw(200.00)
t2.display()
print("="*50)
t3=Emp("salman","rayachoty",10003,37000.00)
t3.deposite(100.00)
t3.withdraw(200.00)
t3.display()
print("="*50)
del t1

print("total employees are in this company:",Emp.empcnt)
 
    
