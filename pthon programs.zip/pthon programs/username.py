a="mubarak"
b="muba"
while True:
    i=input("enter username")
    if i in a:
        print("hello mubarak")
    else:
        print("invalid user name try again")
        continue
    while True:
        j=input("enter password")
        if j in b:
            print("_"*50)
            print('''\t mubarak\n \t                                                id=1001
\t age                              :23''')
            break
        else:
            print("invalid user name and password")
    break

        
    
