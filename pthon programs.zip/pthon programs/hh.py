x=[["mubaaaa",55,25],["hai",54,58]]
