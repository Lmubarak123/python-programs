name=input("enter the user name")
psw=input("enter the password")
while name!='mubark' and psw!='python':
    print("invalid user name and password")
print("welcom mubarak")
