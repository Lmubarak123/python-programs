from bankk import deposite(100)


