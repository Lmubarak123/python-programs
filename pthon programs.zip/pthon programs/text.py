class Valuetosmallerror(Exception):
    pass
class Valuetolargeerror(Exception):
    pass
number=10
while True:
    try:
        num=int(input("enter a number"))
        if num < number:
            raise Valuetosmallerror
        elif num > number:
            raise Valuetolargeerror
        break
    except(Valuetosmallerror):
        print("This  value is too small, try agian")
    except(Valuetolargeerror):
        print("This value is too large,try agian")
print("congrations! You humber is correctly")
