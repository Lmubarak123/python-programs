class Muba:
    a='mubarak'
    b='malik'
    def display(self):
        print(Muba.a)
        print(Muba.b)
    def modify(self):
      Muba.a=Muba.a='pavan'
      Muba.b=Muba.b='vinod'
m=Muba()
m.modify()
m.display()


