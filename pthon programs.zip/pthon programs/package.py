import bankk
print(bankk.a)
print(bankk.Cust.cbname)
print(bankk.Cust.__init__.self.cname)
