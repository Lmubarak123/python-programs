class Malik:
    a=int(input("Enter  first number"))
    b=int(input("Enter second number"))
    c=0
    def Mul(self):
        Malik.c=Malik.a*Malik.b
        print(Malik.c)
    def mub(self):
        Malik.c=Malik.a+Malik.b
        print(Malik.c)
m=Malik()
m.Mul()
m.mub()
        
