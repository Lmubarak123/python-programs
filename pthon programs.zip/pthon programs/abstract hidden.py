class Muba:
    __a=10025
    def __init__(self):
        self.__b=35244
    def __m1(self):
        print("m1 in clss Muba")
class Alfa(Muba):
    __c=2222
    def __init__(self):
        self.__d=4323
    def __m2(self):
        print("m2 in class Alfa")
        super().__init__()
    def display(self):
        print(Alfa.__c)
        print(self.__d)
        self.__m2()
        print(self._Muba__a)
        print(self._Muba__b)
        self._Muba__m1()
m1=Alfa()
m1.display()

