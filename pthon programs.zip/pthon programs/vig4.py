x='mubarak'
y='muba'
while True:
    i=input("enter user name")
    if i in x:
        print("hello")
    else:
        print("invalid user name:")
while True:
    j=input("enter password")
    if j in y:
        print("login sucessfu")
    else:
        print("invalid username and password")
      
    
      
