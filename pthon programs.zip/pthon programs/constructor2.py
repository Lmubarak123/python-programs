class Test:
    def __init__(self,a,b):
        self.x=a
        self.y=b
    def display(self):
        print(self.x)
        print(self.y)
s1=Test(1000,2000)
s1.display()
s2=Test(2000,3000)
s2.display()
s3=Test(4000,5000)
s3.display()
