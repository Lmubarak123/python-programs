'''import matplotlib.pyplot as plt
plt.plot([1,2,3],[5,7,4])
plt.show()

import matplotlib.pyplot as plt
x=[1,2,3,4,5,6,7,8,9,10]
y=[5,6,7,3,6,7,21,12,14,8]
z=[1,2,3,4,5,6,7,8,9,10]
x2=[1,2,3,4,5,6,7,8,9,10]
y2=[7,8,6,5,12,14,23,21,15,11]
z2=[21,5,8,6,12,13,14,15,16,14,]
plt.plot(x,y,label='india')
plt.plot(x2,y2,label='england')
plt.plot(z,z2,label='andharapradesh')
plt.xlabel('over number')
plt.ylabel('runs')
plt.title('score comparsion')
plt.legend()
plt.show()

#### Bar graph

import matplotlib.pyplot as plt
plt.bar([1,3,5,7,9],[5,2,7,8,2],label="example one",color='r')
plt.bar([2,4,6,8,10],[8,6,2,5,6],label="example two",color='g')
plt.bar([3,4,2,5,7],[4,6,8,9,8],label="example three",color='b')
plt.legend()
plt.xlabel('bar number')
plt.ylabel('var height')
plt.title('my graph')
plt.show()

###### Historical graphs

import matplotlib.pyplot as plt
population_ages=[2,42,4,55,6,45,96,58,47,5,8,122,120,54,62,15,25,36,45,6,5,55,130,122,15]
bins=[0,10,20,30,40,50,60,70,80,90,100,110,120,130]
plt.hist(population_ages,bins,histtype='bar',rwidth=0.8)
plt.xlabel('age range')
plt.xlabel('total no of people')
plt.title('my graph')
plt.legend()
plt.show()'''

###### Scatter graphs

import matplotlib.pyplot as plt
x=[1,2,3,4,5,6,7,8]
y=[5,2,4,2,1,4,5,2]
plt.scatter(x,y,label='skitscat',color='b',s=50,marker="c")
plt.xlabel('x')
plt.ylabel('y')
plt.title('my graph')
plt.legend()
plt.show()
'''
#####

import matplotlib.pyplot as plt
days=[1,2,3,4,5]
sleeping=[7,8,6,11,7]
eating=[2,3,4,3,2]
working=[7,8,7,2,2]
playing=[8,5,7,8,13]
plt.plot([],[],color='k',label='sleeping',linewidth=5)
plt.plot([],[],color='c',label='eating',linewidth=5)
plt.plot([],[],color='r',label='working',linewidth=5)
plt.plot([],[],color='g',label='playing',linewidth=5)
plt.stackplot(days,sleeping,eating,working,playing,colors=['k','c','r','g'])
plt.xlabel('days')
plt.ylabel('hours')
plt.title('my graph')
plt.legend()
plt.show()

'''
##### Pie graph

import matplotlib.pyplot as plt
slices=[7,2,2,13]
activities=['sleeping','eating','working','playing']
cols=['c','m','r','g']
plt.pie(slices,labels=activities,
        colors=cols,
        startangle=90,
        shadow=True,
        explode=(0,0.1,0,0),
        autopct=('%1.1f%%'))
plt.title('my graph')
plt.show()




























                                                           
                                                    




















































































