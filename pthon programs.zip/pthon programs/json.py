import json
data={}
data['people']=[]
data['people'].append({
    'name':'scott',
    'website':'facebook.com',
    'from':'nebraska'})
data['people'].append({
    'name':'larry',
    'website':'google.com',
    'from':'michigan'})
data['people'].append({
    'name':'tim',
    'website':'apple.com',
    'from':'Alabma'})
fil=open('data.json','w')
json.dump(data,fil)
fil.close()
'''
import json
json_file=open('data.json')
data=json.load(json_file)
json_file.close()
lst=data['people']
for p in lst:
    print('Name:'+p['name'])
    print('Website:'+p['website'])
    print('From:'+p['from'])
    '''





















    


                       
                       
