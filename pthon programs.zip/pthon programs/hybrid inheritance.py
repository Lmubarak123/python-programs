class X:
    def m1(self):
        print("hai m1 in X class")
class Y:
    def m2(self):
        print("hai m2 in Y class")
class Z:
    def m3(self):
        print("hai m3 in Z class")
class A(X,Y):
    def m4(self):
        print("hai m4 in A class")
class B(Y,Z):
    def m5(self):
        print("hai m5 in B class")
class M(A,B,Z):
    def m6(self):
        print("hai m6 in M calss")
a1=A()
a1.m1()
a1.m2()
a1.m4()
b1=B()
b1.m3()
b1.m5()
m1=M()
m1.m6()

