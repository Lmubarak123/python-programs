x={"chock":["munch","perk","kitkat"],
   "fruit":["apple","banana","ornge"],
   "cooldrinks":["sprit","mazza","thumsup"]}
print(x)

kv=input("enter one item")
print(x.get(kv))
enumerate(kv)
