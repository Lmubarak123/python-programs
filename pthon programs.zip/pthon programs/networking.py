'''import socket
s=socket.socket()
host=socket.gethostname()
port=9998
s.bind((host,port))
s.listen(5)
while True:
    c,addr=s.accept()
    print('got connection from',addr)
    c.close()
    
###SMS#####

import requests
mobno=input("enter mobile no")
msg=input("enter message")
res=('http://textbelt.com/text',{'phone':mobno,'message':msg,'key':'textbelt'})
result=res.json()
data=result["success"]
if data:
    print("sms sent successfully")
else:
    print("sms send failed")
    print(result["error"])
'''
###### Email ######

import smtplib
content="welcom to mubarak office"
mail=smtplib.SMTP('smtp.gmail.com',576)
mail.ehlo()
mail.starttls()
mail.login('vinodkumaryv96@gmail.com','vinod347')
mail.sendmail('vinodkumaryv96@gmail.com','vinodkumaryv347@gmail.com',content)
mail.close()



























