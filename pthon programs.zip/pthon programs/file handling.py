'''x=open("mubarak.txt")
print(x.read())
x.close()

x=open("bank.py")
print(x.read())
print(x.tell())
x.close()

x=open("bank.py")
print(x.seek(50))
print(x.read())
print(x.tell())
x.close()

"""write data in to file"""
x=open("mubarak.py","w")
x.write(" name:: Mubarak\nstuding::MCA\ncollege::SVU\ncity:: Tirupathi\n")
x.close()

"""read line method line by line"""

x=open("mubarak.py")
lines=x.readlines()
print(lines)
for p in lines:
    print(p,end=" ")
x.close()

x=open("mubarak.py","a")
x.write(" hai, this program is add extera matter in alread saved file")
x.close()'''































