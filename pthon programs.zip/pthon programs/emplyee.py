class Test:
    """employee details"""
    cbname="STATE BANK OF INDAI"
    def __init__(self,ename,eadd,eid,ephone,esal):
        self.ename=ename
        self.eadd=eadd
        self.eid=eid
        self.ephone=ephone
        self.esal=esal
    def hrfunction(self,hr):
        self.esal=self.esal+hr
    def cut(self,pf):
        self.esal=self.esal-pf
    def display(self):
        print(Test.cbname)
        print(self.ename)
        print(self.eadd)
        print(self.eid)
        print(self.ephone)
        print(self.esal)
    
x1=Test("mubarak","kadapa",1001,9160225744,10000.00)
x1.hrfunction(float(input("enter HR amout")))
x1.display()
x1.cut(float(input("enter PF amount")))
x1.display()

        
