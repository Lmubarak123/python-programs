x={"java":80,"python":99,"aws":78,"devops":69}
print(x)
k=x.keys()
for p in k:
    print(p)
v=x.values()
for i in v:
    print(i)
kv=x.items()
for q in kv:
    print(q)
    print(q[0],q[1])
for  a,b in kv:
    print(a,b)
    
