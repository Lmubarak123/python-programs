import re
reg=re.compile (r"[A-Z]+")
reg1=re.compile(r"[a-z]+")
reg2=re.compile(r"[0-9]+")
reg3=re.compile(r"\W")
while True:
    password=input("Enter your PASSWORD")
    result=reg.search(password)
    res=reg1.search(password)
    ress=reg2.search(password)
    ro=reg3.search(password)
    if result:
        if res:
            if ress:
                if ro:
                    print("\n\n","$$$$$$      Your PASSWORD is valid       $$$$$")
                    break
                else:
                    print("your PASSWORD must b at least one Special character")
            else:
                print("your PASSWORD must b at least one number")
        else:
            print(" your PASSWORD must b at least one lower letter")
    else:
        print("your PASSWORD must b at least one capatal letter")
print("\n\n")
print("*"*80)
print("WELCOM TO YOUR GMAIL :- ",password)
print("*"*80)
