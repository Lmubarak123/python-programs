import re
reg=re.compile (r"[a-zA-Z]+[0-9]+@[a-z]{5}.[a-z]+")
while True:
    gmail=input("Enter your Gmail")
    result=reg.search(gmail)
    if result:
        print(" your Gmail is Valid")
        break
    else:
        print("Gmail should be in \n one Capital letter and  \n one lower letter \n one numberical")
  
print("\n\n")
print("*"*60)
print("Thankyou  now you are sing to ur gmail:- ",gmail)
print("*"*60)
