n=int(input("enter number of rows"))
for i in range(n):
    n=n+1
    for j in range(i):
        
        print("*",end=" ")
    print()
m=int(input("enter number of rows"))
for q in range(m,0,-1):
    for p in range(q):
        print("*",end=" ")
    print()
l=int(input("enter number of rows"))
for a in range(l,0):
    print(a)
