'''a,b=[int(x) for x in input("Enter 2 numbers").split(',')]
print(a*b)

x=input("enter any equations")
result=eval(x)
print("The Result:",result)

ex:-2
x=eval(input("enter any data"))
print(type(x))

06/02/2019
----------------
for loop:-
-----------
for i in range(10):
print("hello")

ex:-1

for i in range(21):
if x%2==0:
print(x)
if x%2!=0:
print(x)

ex:-2
for x in range(1,21,2)
print(x)

ex:-2
--------
name=input("enter the user name")
psw=input("enter the password")
while name!='mubark' and psw!='python':
    print("invalid user name and password")
print("welcom mubarak")

while:-
---------
n=int(input("enter the int value:"))
sum=0
i=1
while i<=n:
    sum=sum+i
    i=i+1
print("the number ",n,"value is ",sum)


Nested loop:-
------------------
for i in range(4):
    for j in range(4):
        print("i={} and j={}".format(i,j,))

#print nuber of row like ******'s
n=int(input("enter the number of rows"))
for i in range(n):
    n=n+1
    for j in range(i):
        print("*",end=" ")
    print()

Ex-2
#print number of rows ****'s
n=int(input("enter number of row"))
for i in range(n): # i represent no of rows
    for j in range(n):  # j represnt no of *'s
        print("*",end=" ")
    print()

             (or)

n=int(input("enter number of row"))
for i in range(n):
    print("*  "*n) '''

n=int(input("enter the number of rows"))
for i in (n,0):
    n=n+1
    for j in range(i):
        print("*",end=" ")
    print()
    
    
    















        

        
