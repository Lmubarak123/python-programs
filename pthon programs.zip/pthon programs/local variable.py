class Test:
    def m1(self):
        a=100
        b=200
        
        print(a+b)
        print(a*b)
    def m2(self):
        c=300
        d=400
        print(c-d)
        print(d/c)
""" print(a+d)========>error  because local variable is particular
place operation is recommanded"""
v1=Test()
v1.m1()
v1.m2()
        
