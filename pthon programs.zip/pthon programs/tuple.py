class x:
    def __init__(self,a,b,c):
        self.a=a
        self.b=b
        self.c=c
        print('constructor')
    def add(self):
        self.c=self.b+self.a
        print(self.c)
x1=x('2','3','0')
x1.add()
