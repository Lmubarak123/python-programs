
for j in list(range(1,11)):
           print(j)
