n=int(input("enter no of row"))
for i in range(n,0,-1):
    for j in range(0,i):
        print("*",end=" ")
    print()


n=int(input("enter no of row"))
for i in range(n,0,-1):
    for j in range(1,i):
        print(j,end=" ")
    print()    

n=int(input("enter no of row"))
for i in range(n):
    n=n+1
    for j in range(i):
        print("*",end=" ")
    print()

n=int(input("enter no of row"))
for i in range(n):
    n=n+1
 
    for j in range(i):
        print(j,end=" ")
    print()




