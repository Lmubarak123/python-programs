import cx_Oracle
import time
con=cx_Oracle.connect('system','mubarak','localhost:1521/orcl')
print("connection is established")
cur=con.cursor()
cur.arraysize=100
start=time.time()
cur.execute('select * from bigtab')
for p in cur:
    pass
elapsed=(time.time()-start)
print(elapsed,"seconds")
cur.close()
con.close()
print("connection is close")
