x=['manager','employee','worker','pune']
print(x)
a=int(input("enter salary amount"))
if a>=30000:
    print("employee profession : manager")
    print("name : pavan")
    print("add  :  kadapa")
    print("P\F :  200")
elif a<30000:
    print("employee")
    print("name:malik")
    print("add:tiupathi")
    print("P\F:200")
elif a<20000:
    print("woker")
    print("name:vinay")
    print("add:kadapa")
    print("P\F:200")
elif a<10000:
    print("pune")
    print("name:vinod")
    print("add:kadapa")
    print("P\F:200")
else:
    print("employee is not avaible")
