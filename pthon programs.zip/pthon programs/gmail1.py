import re
reg=re.compile (r"[A-Z]+")
reg1=re.compile(r"[a-z]+")
reg2=re.compile(r"[0-9]+")
reg3=re.compile(r"@[a-z]{5}.[a-z]{3}")
while True:
    gmail=input("Enter your Gmail")
    result=reg.search(gmail)
    res=reg1.search(gmail)
    ress=reg2.search(gmail)
    ro=reg3.search(gmail)
    if result:
        if res:
            if ress:
                if ro:
                    print("\n\n","$$$$$$      Your Gmail is valid       $$$$$")
                    break
                else:
                    print("your Gmail must b in gmail.com,yahoo.com format")
            else:
                print("your Gmail must b one number")
        else:
            print(" your Gmail must b one lower letter")
    else:
        print("your Gmail must b one capatal letter")
print("\n\n")
print("*"*80)
print("WELCOM TO YOUR GMAIL :- ",gmail)
print("*"*80)
