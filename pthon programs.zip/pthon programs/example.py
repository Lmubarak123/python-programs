class Test:
    """"dsmljdifgjijfgjij"""
    a=1000
    b=2000
    def display(self):
            print(Test.a)
            print(Test.b)
print(Test.a)
h1=Test()
h1.display()


