'''import pandas as pd
import matplotlib.pyplot as plt
names=['mubark','rafi','malik','masthanvali','mastan','vinod','pavan','vinay']
births=['24','23','21','30','26','45','43','33']
dataset=list(zip(names,births))
print(dataset)
df=pd.DataFrame(data=dataset,columns=['Names','Births'])
print(df)
df.to_csv('births1101.csv',index=False,header=False)
df=pd.read_csv('births1101.csv')
print(df)
df=pd.read_csv('births1101.csv',header=None)
print(df)
df=pd.read_csv('births1101.csv',names=['Names','Births'])
print(df)
Sorted=df.sort_values(['Births'],ascending=True)
print(Sorted)
print(Sorted.head(1))
print(df['Births'].max())
print(df['Births'].mean())
print(df['Births'].std())
plt.plot([1,2,3,4,5,6,7,8],list(Sorted['Births']))
plt.show()'''

###### with pie chart
import pandas as pd
import matplotlib.pyplot as plt
names=['mubark','rafi','malik','masthanvali','mastan','vinod','pavan','vinay']
births=['24','23','21','30','26','45','43','33']
dataset=list(zip(names,births))
print(dataset)
df=pd.DataFrame(data=dataset,columns=['Names','Births'])
print(df)
df.to_csv('births1101.csv',index=False,header=False)
df=pd.read_csv('births1101.csv')
print(df)
df=pd.read_csv('births1101.csv',header=None)
print(df)
df=pd.read_csv('births1101.csv',names=['Names','Births'])
print(df)
Sorted=df.sort_values(['Births'],ascending=True)
print(Sorted)
Sot=df.sort_values(['Names'])
print(Sot)
print(Sorted.head(1))
print(df['Births'].max())
print(df['Births'].mean())
print(df['Births'].std())
slices=list(Sorted['Births'])
activities=list(Sot['Names'])
cols=['c','m','r','g','r','b','k','b']
plt.pie(slices,labels=activities,colors=cols,startangle=90,shadow=True,explode=(0,0,0,0,0,0.1,0,0))
plt.show()

