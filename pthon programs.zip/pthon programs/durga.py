n=int(input("enter the number of rows"))
for i in (n,-1,-1):
    n+=1
    for j in range(i):
        print("*")
    print()
    
