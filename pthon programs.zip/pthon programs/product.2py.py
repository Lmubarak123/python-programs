x={"choculates":["park","munch","dailymalik","asha"],
   "fruits":["apple","banana","ornge","goa"],
   "cooldrinks":["sprint","cococola","mazza","lemka" ]}
y=input("enter a item name")
for i,j in x.items():
    if i==y:
        for k,l in enumerate(j):
            print(k+1,")",l)
        break
else:
    print("the item is not there in the list")
    
